READ ME:
*********

This software is developed and copyrighted by HIOX Softwares.
This is given under The GNU General Public License (GPL).
This version is hboxin 1.0


Features:
----------
a) To start this online box-in game, click the START PLAY.
b) Draw a single line between two points at a time, try to complete a box.
c) Score will be displayed while playing this java script box-in online
computer game.
d) Message will be displayed if you win or loss the game.
e) Download the free javascript game code and use it.


Downloads:
-----------
Please visit our site http://www.hscripts.com and do the download


Installation:
--------------
Please take 5 minutes time and read installation instructions carefully and
completely! This will ensure a proper and easy installation. 

a) Unzip the hboxin.zip to extract the files hboxin/box-in.html, /bjfun.js,
hboxin/btab.js, hboxin/images and hboxin/README.txt.
b) To use this box-in computer game java script, you have to run
hboxin/box-in.html in any web browser.


Releases:
----------
Release Date hboxin 1.0: 07-04-2008.

On any suggestions mail to us at support@hscripts.com

Visit us at http://www.hscripts.com
Visit us at http://www.hioxindia.com
