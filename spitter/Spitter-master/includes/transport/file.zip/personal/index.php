<header><meta content='width=device-width, initial-scale=1' name='viewport'/> <center><h1>Welcome, [CHANGE IN INDEX.PHP], to your personal web server. This template is easily customized (It is only two lines of code!) and added to. Click <a href="files.php" class="button">here</a> to go to the file manager and store your data on your own server!</h1></center> </header>

<body><a href="files.php" class="button">File Manager</a></body>
