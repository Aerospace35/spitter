# Spitter
This is a repo containing all the source code for the Spitter chat and socialization platform.
If you want, you can add features or optimize it, or just secure it. Below are some things I might add, or a to do list that you can help with.

#Fix styles
#Optimize size of forms
#add more easter eggs
#add a secure admin login system
#
#
#
#
#
#
