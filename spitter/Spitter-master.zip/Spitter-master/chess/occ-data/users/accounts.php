<?php /* ***** PASSWORDS ***** */
$passwords = array ( 
  "guest" => "guest",
  "guest2" => "guest",
  "test" => "test",
  "Brodie" => "19984",
  "Spitter1" => "Spitter1",
  "Spitter2" => "Spitter2",
  "Spitter3" => "Spitter3",
  "Spitter4" => "Spitter4"
);
/* ***** MAIL-ADDRESSES ***** */
$mail_addresses = array (
  "guest" => "dummy@nowhere.org",
  "guest2" => "someone@world.net"
); ?>
