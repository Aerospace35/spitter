<?php header("Refresh:5; url=$room");
