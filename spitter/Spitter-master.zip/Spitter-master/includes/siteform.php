<form action="#" method="post">
New room name: <input type="text" name="name"><br>
<input type="submit" name="submit" value="Create">
</form>
