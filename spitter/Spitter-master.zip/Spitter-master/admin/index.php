<style> body {background-color: black;} </style>
<body>
<iframe width="100%" height="100%" src="../admin.php"></iframe>
</body>
